
# Day 29 - Capstone

**Learning Objectives**
Build mini office network.

**Tasks / Lab**
Implement: VLANs, DHCP, DNS, NAT, ACL.

**Challenge**
Document and screenshot the working network.

**Notes**
- Open the empty Packet Tracer file `Day29_Capstone.pkt` and build the topology described above from scratch.
- Save your work frequently.

