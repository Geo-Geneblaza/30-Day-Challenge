
# Day 14 - Week2Review

**Learning Objectives**
Review addressing & tools.

**Tasks / Lab**
Take a short practice quiz.

**Challenge**
Identify weak areas for revision.

**Notes**
- Open the empty Packet Tracer file `Day14_Week2Review.pkt` and build the topology described above from scratch.
- Save your work frequently.

