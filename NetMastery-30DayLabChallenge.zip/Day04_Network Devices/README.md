
# Day 04 - Network Devices

**Learning Objectives**
Learn hub, switch, router, AP, firewall.

**Tasks / Lab**
Identify devices in your home.

**Challenge**
Explain routing vs switching.

**Notes**
- Open the empty Packet Tracer file `Day04_Network Devices.pkt` and build the topology described above from scratch.
- Save your work frequently.

