
# Day 28 - Automation

**Learning Objectives**
Intro to Python & Netmiko.

**Tasks / Lab**
Install Python and run a simple script.

**Challenge**
Write a script to pull interface status (pseudo).

**Notes**
- Open the empty Packet Tracer file `Day28_Automation.pkt` and build the topology described above from scratch.
- Save your work frequently.

