
# Day 19 - DNSServer

**Learning Objectives**
DNS name resolution.

**Tasks / Lab**
Configure a DNS server in Packet Tracer.

**Challenge**
Add an alias (CNAME) entry.

**Notes**
- Open the empty Packet Tracer file `Day19_DNSServer.pkt` and build the topology described above from scratch.
- Save your work frequently.

