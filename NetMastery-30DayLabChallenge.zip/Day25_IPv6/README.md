
# Day 25 - IPv6

**Learning Objectives**
IPv6 addressing and types.

**Tasks / Lab**
Assign IPv6 addresses in Packet Tracer.

**Challenge**
Ping an IPv6 host.

**Notes**
- Open the empty Packet Tracer file `Day25_IPv6.pkt` and build the topology described above from scratch.
- Save your work frequently.

