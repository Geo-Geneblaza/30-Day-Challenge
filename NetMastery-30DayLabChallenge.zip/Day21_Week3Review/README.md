
# Day 21 - Week3Review

**Learning Objectives**
Review switching & routing topics.

**Tasks / Lab**
Combine features in one lab.

**Challenge**
Document configuration snippets.

**Notes**
- Open the empty Packet Tracer file `Day21_Week3Review.pkt` and build the topology described above from scratch.
- Save your work frequently.

