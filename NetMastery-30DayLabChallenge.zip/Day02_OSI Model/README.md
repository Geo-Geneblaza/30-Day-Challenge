
# Day 02 - OSI Model

**Learning Objectives**
Memorize 7 OSI layers and their purpose.

**Tasks / Lab**
Create flashcards for each layer.

**Challenge**
Explain where HTTP fits in the OSI model.

**Notes**
- Open the empty Packet Tracer file `Day02_OSI Model.pkt` and build the topology described above from scratch.
- Save your work frequently.

