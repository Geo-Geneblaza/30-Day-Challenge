
# Day 05 - EthernetMAC

**Learning Objectives**
Ethernet frames and MAC addresses.

**Tasks / Lab**
Find your MAC address on your PC.

**Challenge**
Change MAC on a VM and observe ARP.

**Notes**
- Open the empty Packet Tracer file `Day05_EthernetMAC.pkt` and build the topology described above from scratch.
- Save your work frequently.

