
# Day 12 - GatewayDNS

**Learning Objectives**
Gateway and DNS basics.

**Tasks / Lab**
Ping gateway and 8.8.8.8; use nslookup.

**Challenge**
Describe what happened during DNS lookup.

**Notes**
- Open the empty Packet Tracer file `Day12_GatewayDNS.pkt` and build the topology described above from scratch.
- Save your work frequently.

