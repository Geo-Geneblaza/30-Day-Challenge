
# Day 10 - SubnetPractice

**Learning Objectives**
Practice binary subnetting.

**Tasks / Lab**
Solve 5 subnetting problems.

**Challenge**
Time yourself and improve speed.

**Notes**
- Open the empty Packet Tracer file `Day10_SubnetPractice.pkt` and build the topology described above from scratch.
- Save your work frequently.

