
# Day 18 - DHCP

**Learning Objectives**
How DHCP assigns IP addresses.

**Tasks / Lab**
Configure DHCP server in Packet Tracer.

**Challenge**
Reserve an address for a specific MAC.

**Notes**
- Open the empty Packet Tracer file `Day18_DHCP.pkt` and build the topology described above from scratch.
- Save your work frequently.

