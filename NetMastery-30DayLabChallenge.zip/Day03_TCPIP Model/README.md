
# Day 03 - TCPIP Model

**Learning Objectives**
Compare TCP/IP and OSI models.

**Tasks / Lab**
Match protocols to layers.

**Challenge**
List examples of protocols on each layer.

**Notes**
- Open the empty Packet Tracer file `Day03_TCPIP Model.pkt` and build the topology described above from scratch.
- Save your work frequently.

