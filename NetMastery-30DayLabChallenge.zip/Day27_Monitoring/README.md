
# Day 27 - Monitoring

**Learning Objectives**
Wireshark and tcpdump basics.

**Tasks / Lab**
Capture a ping packet in Wireshark.

**Challenge**
Analyze DNS or TLS handshake.

**Notes**
- Open the empty Packet Tracer file `Day27_Monitoring.pkt` and build the topology described above from scratch.
- Save your work frequently.

