# NetMastery-30DayLabChallenge

This repository contains a 30-day networking lab challenge.  
Each day folder includes:
- an **empty** Packet Tracer placeholder file (`.pkt`) for you to build the topology from scratch, and
- a `README.md` with step-by-step objectives and tasks.

**How to use**
1. Download and extract the repo.
2. Open each `DayXX_*.pkt` in Cisco Packet Tracer (create devices/cables as described in the day's README).
3. Follow the README tasks and challenges.

**Notes**
- Packet Tracer `.pkt` files here are placeholders (empty). They are intentionally empty so you can practice building the topology from scratch.
- All instructional content is in English.
- If you want fully pre-configured `.pkt` files instead, tell me and I can prepare those next.

Good luck — you're on your way to mastering networking!
