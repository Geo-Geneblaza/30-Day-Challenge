
# Day 01 - Network Basics

**Learning Objectives**
Understand network types (LAN, WAN, WLAN).

**Tasks / Lab**
Draw your home network diagram. Identify devices.

**Challenge**
Add one more device to your diagram and explain its role.

**Notes**
- Open the empty Packet Tracer file `Day01_Network Basics.pkt` and build the topology described above from scratch.
- Save your work frequently.

