
# Day 17 - StaticRouting

**Learning Objectives**
Static & default routes.

**Tasks / Lab**
Configure static routes between two networks.

**Challenge**
Add a redundant static route and test.

**Notes**
- Open the empty Packet Tracer file `Day17_StaticRouting.pkt` and build the topology described above from scratch.
- Save your work frequently.

