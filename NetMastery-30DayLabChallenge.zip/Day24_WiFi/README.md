
# Day 24 - WiFi

**Learning Objectives**
802.11 standards & encryption.

**Tasks / Lab**
Scan home Wi-Fi and note settings.

**Challenge**
Change channel to reduce interference.

**Notes**
- Open the empty Packet Tracer file `Day24_WiFi.pkt` and build the topology described above from scratch.
- Save your work frequently.

