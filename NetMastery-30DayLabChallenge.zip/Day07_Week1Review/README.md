
# Day 07 - Week1Review

**Learning Objectives**
Review all week 1 topics.

**Tasks / Lab**
Create a mind map.

**Challenge**
Quiz yourself with 10 questions.

**Notes**
- Open the empty Packet Tracer file `Day07_Week1Review.pkt` and build the topology described above from scratch.
- Save your work frequently.

