
# Day 30 - FinalReview

**Learning Objectives**
Review entire course.

**Tasks / Lab**
Create final network diagram and documentation.

**Challenge**
Publish your repo on GitHub and share link.

**Notes**
- Open the empty Packet Tracer file `Day30_FinalReview.pkt` and build the topology described above from scratch.
- Save your work frequently.

