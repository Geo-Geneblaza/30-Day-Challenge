
# Day 09 - SubnetMasks

**Learning Objectives**
Learn CIDR and masks.

**Tasks / Lab**
Do 10 subnet identification exercises.

**Challenge**
Create one custom subnetting problem.

**Notes**
- Open the empty Packet Tracer file `Day09_SubnetMasks.pkt` and build the topology described above from scratch.
- Save your work frequently.

