
# Day 13 - TroubleshootTools

**Learning Objectives**
ping, tracert, nslookup, arp.

**Tasks / Lab**
Practice these commands on your PC.

**Challenge**
Capture output and save to a file.

**Notes**
- Open the empty Packet Tracer file `Day13_TroubleshootTools.pkt` and build the topology described above from scratch.
- Save your work frequently.

