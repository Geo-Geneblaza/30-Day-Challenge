
# Day 11 - PrivatePublicIPs

**Learning Objectives**
Private vs Public IP ranges.

**Tasks / Lab**
Assign private IPs to 3 devices.

**Challenge**
Explain why NAT is needed.

**Notes**
- Open the empty Packet Tracer file `Day11_PrivatePublicIPs.pkt` and build the topology described above from scratch.
- Save your work frequently.

