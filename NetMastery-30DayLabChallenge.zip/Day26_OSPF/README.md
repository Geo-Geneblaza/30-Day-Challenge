
# Day 26 - OSPF

**Learning Objectives**
Intro to OSPF basics.

**Tasks / Lab**
Configure OSPF between 2 routers.

**Challenge**
Add a third router and observe LSAs.

**Notes**
- Open the empty Packet Tracer file `Day26_OSPF.pkt` and build the topology described above from scratch.
- Save your work frequently.

