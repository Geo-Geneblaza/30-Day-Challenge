
# Day 22 - ACLs

**Learning Objectives**
Access Control Lists basics.

**Tasks / Lab**
Apply ACL to block a PC from the internet.

**Challenge**
Create an ACL that permits only HTTP.

**Notes**
- Open the empty Packet Tracer file `Day22_ACLs.pkt` and build the topology described above from scratch.
- Save your work frequently.

