
# Day 20 - NAT

**Learning Objectives**
Understand PAT and NAT types.

**Tasks / Lab**
Enable NAT on a router for internet access.

**Challenge**
Test port translation.

**Notes**
- Open the empty Packet Tracer file `Day20_NAT.pkt` and build the topology described above from scratch.
- Save your work frequently.

