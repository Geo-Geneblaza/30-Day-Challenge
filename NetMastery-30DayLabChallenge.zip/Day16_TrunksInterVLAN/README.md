
# Day 16 - TrunksInterVLAN

**Learning Objectives**
Trunk ports and router-on-a-stick.

**Tasks / Lab**
Configure inter-VLAN routing.

**Challenge**
Document the trunk config.

**Notes**
- Open the empty Packet Tracer file `Day16_TrunksInterVLAN.pkt` and build the topology described above from scratch.
- Save your work frequently.

