
# Day 06 - Domains

**Learning Objectives**
Broadcast vs collision domains.

**Tasks / Lab**
Simulate hub vs switch in Packet Tracer.

**Challenge**
Document differences you observed.

**Notes**
- Open the empty Packet Tracer file `Day06_Domains.pkt` and build the topology described above from scratch.
- Save your work frequently.

