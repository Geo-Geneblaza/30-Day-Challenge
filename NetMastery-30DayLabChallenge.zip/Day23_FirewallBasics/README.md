
# Day 23 - FirewallBasics

**Learning Objectives**
Firewall rules and concepts.

**Tasks / Lab**
Simulate blocking HTTP in Packet Tracer.

**Challenge**
Explain stateful vs stateless behavior.

**Notes**
- Open the empty Packet Tracer file `Day23_FirewallBasics.pkt` and build the topology described above from scratch.
- Save your work frequently.

