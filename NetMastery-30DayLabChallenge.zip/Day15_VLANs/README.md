
# Day 15 - VLANs

**Learning Objectives**
VLAN concepts and benefits.

**Tasks / Lab**
Create 2 VLANs in Packet Tracer.

**Challenge**
Add a third VLAN as a challenge.

**Notes**
- Open the empty Packet Tracer file `Day15_VLANs.pkt` and build the topology described above from scratch.
- Save your work frequently.

