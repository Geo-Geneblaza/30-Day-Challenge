
# Day 08 - IPv4Structure

**Learning Objectives**
Understand IPv4 network/host parts.

**Tasks / Lab**
Assign manual IP to a PC in Packet Tracer.

**Challenge**
Document the IP scheme you used.

**Notes**
- Open the empty Packet Tracer file `Day08_IPv4Structure.pkt` and build the topology described above from scratch.
- Save your work frequently.

